# Crochet Mania — Event Manager
Version premium avec page d'accueil visuelle basée sur l'identité de Crochet Mania et l'affiche fournie.

Fichiers :
- index.html
- crochet-mania-logo.png
- crochet-mania-poster.jpg

Fonctions : accueil premium, compte à rebours, planning, sponsors et lettres, réunions, investissements, promotion, budget, paramètres, sauvegarde locale et export JSON.
